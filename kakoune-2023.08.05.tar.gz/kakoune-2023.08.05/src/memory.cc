#include "memory.hh"

namespace Kakoune
{

MemoryStats memory_stats[(size_t)MemoryDomain::Count] = {};

}
