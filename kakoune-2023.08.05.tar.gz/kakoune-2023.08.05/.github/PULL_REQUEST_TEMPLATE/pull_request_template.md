<!--
If this is your first contribution to the Kakoune project, make sure to
include an empty "waiver" commit to your Pull Request, as described in the
following document:

https://github.com/mawww/kakoune/blob/master/CONTRIBUTING
-->
